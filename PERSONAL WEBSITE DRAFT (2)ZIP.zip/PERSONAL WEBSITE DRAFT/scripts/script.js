// script.js

function loadPage(page) {
    // Set up the pages content for dynamic loading
    let content = {
        'home': `
            <h2>Welcome</h2>
            <p>Hello, my name is Jordan Mays, and this is my personal website.</p>
            <p>I am passionate about technology, web development, and cloud computing.</p>
        `,
        'about': `
            <h2>Who I Am</h2>
            <p>My name is Jordan Mays, and I am a website developer, content creator, and aspiring cloud computing expert.</p>
        `,
        'portfolio': `
            <h2>My Portfolio</h2>
            <p>Here are some of my projects:</p>
            <ul>
                <li><strong>Project 1 - Web Development</strong>: A full-stack website project I created using HTML, CSS, JavaScript, and Node.js.</li>
                <li><strong>Project 2 - Content Creation</strong>: Developed video tutorials and blog posts about cloud computing.</li>
                <li><strong>Project 3 - Cloud Computing</strong>: Designed and implemented cloud infrastructure for a startup using AWS services.</li>
            </ul>
        `,
        'experience': `
            <h2>My Experience</h2>
            <p>I have worked as a website developer and content creator for the past 5 years, gaining experience in a variety of industries.</p>
            <ul>
                <li><strong>Web Developer</strong> at XYZ Corp (2020-Present) - Responsible for developing and maintaining websites using modern web technologies.</li>
                <li><strong>Content Creator</strong> at ABC Media (2018-2020) - Created tutorials and blog posts on web development and cloud computing.</li>
                <li><strong>Cloud Computing Intern</strong> at Cloud Solutions Inc. (2017-2018) - Assisted in implementing cloud infrastructure using AWS.</li>
            </ul>
        `,
        'contact': `
            <h2>Contact Me</h2>
            <p>If you'd like to connect, collaborate, or discuss an opportunity, feel free to reach out:</p>
            <p><strong>Email:</strong> <a href="mailto:Jmays18@student.ccc.edu">Jmays18@student.ccc.edu</a></p>
            <p><strong>Phone:</strong> <a href="tel:+19543802112">954-380-2112</a></p>
        `
    };
    
    // Load the appropriate content into the main section
    document.getElementById
